# 아이맥 M1 인계 패키지

- 빌드: 2026-11-26 05:51:28 KST
- 출처: https://github.com/pyw31337/lets
- 구성: launchd plist 13개 · 이전/복원 스크립트 · 런북
- 시크릿 값은 포함하지 않습니다. 이름 목록은 docs/IMAC_M1_HANDOFF.md 참고.

## 아이맥에서
```bash
tar -xzf lets-imac-m1-handoff.tar.gz -C ~/Developer
cd ~/Developer/lets-imac-m1-handoff && bash scripts/migrate_to_imac_m1.sh import --ssd /Volumes/IMAC_MIGRATION
```

## 맥미니에서 (번들을 새로 만들 때)
```bash
bash scripts/migrate_to_imac_m1.sh export --ssd /Volumes/IMAC_MIGRATION
```
